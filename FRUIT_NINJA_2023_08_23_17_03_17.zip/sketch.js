let screen = "intro";
let timer = 0;
let timer2 = 0;

let lives = 10;

let continue2;

let appleX;
let appleY; 
let appleSize = 60;

let greenAppleX;
let greenAppleY;
let greenAppleSize = 60;

let carrotX;
let carrotY;
let carrotSize = 40;

let watermelonX;
let watermelonY;
let watermelonSize = 70;

let blueberryX;
let blueberryY;
let blueberrySize = 55;

let strawberryX;
let strawberryY;
let strawberrySize = 40;

let bombX;
let bombY;
let bomb2X;
let bomb2Y;
let bombSize = 50;

let textY = 230
let textX = 70;

let AppleSpeed;
let greenAppleSpeed;
let carrotSpeed;
let strawberrySpeed;
let watermelonSpeed;
let blueberrySpeed;
let bombSpeed;

let score = 0;

let boxY = 190;

let userAnswerA;
let userAnswerB;
let userAnswerC;
let userAnswerD;

x = 600;
y = 600;

//arrays for questions
let question = [];
let code = [];
let questionImage = [];
let optionA = [];
let optionB = []
let optionC = []
let optionD = []
let answer = []

let randomQuestion;

let song;
let amp;
let songButton;

let arrow;

function setup() {
  
  //song
  //song = loadSound('SpaceGameMusic.mp3');
  song = loadSound('Fruit Ninja - Original Theme Song.mp3');
  amp = new p5.Amplitude();
  
  //song button
  songButton = createButton("Sound");
  songButton.position(10, 575);
  songButton.mousePressed(play);
  
  
  //question 1
  question[0] = "What is the output of this code?";
  code[0] = "String game;\nint l;\ngame = \"Fruit Ninja\";\nl = game.length();\nSystem.out.println(l);"
  questionImage[0] = loadImage('question1.jpg')
  optionA[0] = "A.      10"
  optionB[0] = "B.      11"
  optionC[0] = "C.      9"
  optionD[0] = "D.      5"
  answer[0] = "B"
  
  //question 2
  question[1] = "What is the output of this code?";
  code[1] = "String w;\nchar x;\nw = \"watermelon\";\nx = w.charAt(3);\nSystem.out.println(x);"
  questionImage[1] = loadImage('question2.jpg')
  optionA[1] = "A.      t"
  optionB[1] = "B.      3"
  optionC[1] = "C.      m"
  optionD[1] = "D.      e"
  answer[1] = "D"  
  
  //question 3
  question[2] = "How do you check if 2 strings are equal?";
  optionA[2] = "A.      .equals()"
  optionB[2] = "B.      =="
  optionC[2] = "C.      .equal()"
  optionD[2] = "D.      !="
  answer[2] = "A"
  
  //question 4
  question[3] = "What is the output of this code?";
  code[3] = "String fruit;\nfruit = \"orange\";\nSystem.out.println(fruit.substring(1,fruit.length()));\n"
  questionImage[3] = loadImage('question4.jpg')
  optionA[3] = "A.     orange"
  optionB[3] = "B.      range"
  optionC[3] = "C.      ange"
  optionD[3] = "D.      error"
  answer[3] = "B"  
  
  //question 5
  question[4] = "What is the output of this code?";
  code[4] = "String pear;\nint length;\npear = \"Pear\";\nlength = pear.length();\nSystem.out.println(pear.substring(pear.indexOf(\"e\"), length));";
  questionImage[4] = loadImage('question5.jpg')
  optionA[4] = "A.      ear"
  optionB[4] = "B.      pear"
  optionC[4] = "C.      3"
  optionD[4] = "D.      4"
  answer[4] = "A"
  
  //question 6
  question[5] = "What is the output of this code?";
  code[5] = "String f = \"fruit\";\nString s = \" salad\";\nString e = \"!\";\nSystem.out.println(f.concat(s).concat(e));"
  questionImage[5] = loadImage('question6.jpg')
  optionA[5] = "A.      !"
  optionB[5] = "B.      salad"
  optionC[5] = "C.      fruitsalad!"
  optionD[5] = "D.      fruit salad!"
  answer[5] = "D"
  
  //question 7
  question[6] = "What is the output of this code?";
  code [6] = "String p = \"pineapple\";\nSystem.out.println(p.endsWith(\"apple\"));"
  questionImage[6] = loadImage('question7.jpg')
  optionA[6] = "A.      false"
  optionB[6] = "B.      true"
  optionC[6] = "C.      error"
  optionD[6] = "D.      no output"
  answer[6] = "B"
  
  //question 8
  question[7] = "What is the output of this code?";
  code [7] = "String fruit = \"pomegranate\";\nSystem.out.println(fruit.lastIndexOf(\"e\"));"
  questionImage[7] = loadImage('question8.jpg')
  optionA[7] = "A.      3"
  optionB[7] = "B.      11"
  optionC[7] = "C.      10"
  optionD[7] = "D.      4"
  answer[7] = "C"
  
  //question 9
  question[8] = "Which string method is used to find\n\t\t characters at a specific index?";
  optionA[8] = "A.      charAt()"
  optionB[8] = "B.      indexOf()"
  optionC[8] = "C.      startsWith()"
  optionD[8] = "D.      substring()"
  answer[8] = "A"
  
  //question 10
  question[9] = "What is the output of this code?";
  code [9] = "String p = \"pineapple\";\nString j = \" juice\";\nSystem.out.println(p.substring(p.indexOf(\"a\"),p.length()).concat(j));"
  questionImage[9] = loadImage('question10.jpg')
  optionA[9] = "A.      pineapple juice"
  optionB[9] = "B.      juice"
  optionC[9] = "C.      apple juice"
  optionD[9] = "D.      error"
  answer[9] = "C"  
  
  
  ninja = loadImage("ninja2.png");
  arrow = loadImage("arrow.png")
  createCanvas(600, 600);
  background(0,191,255);
  
  
  appleX= (-1)*random(50, 550);
  appleY= random(50, 500);  
  
  greenAppleX= random(550, 1000);
  greenAppleY= random(50, 500);  
  
  carrotX= (-1)*random(50, 550);
  carrotY= random(50, 550);
  
  strawberryX= (-1)*random(50, 550);
  strawberryY= random(50, 550);

  watermelonX= random(650, 1000);
  watermelonY= random(50, 550); 
  
  blueberryX = random(650, 1000);
  blueberryY = random(650, 1000);
  
  bombX = random(650, 1000);
  bombY = random(50, 550);
  
  bomb2X = (-1)*random(50, 550);
  bomb2Y = random(50, 550);
  
  randomQuestion = random([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
  
  //fruit speeds
  appleSpeed = random([5, 6, 7, 8])
  greenAppleSpeed = random([5, 6, 7, 8])
  carrotSpeed = random([5, 6, 7, 8])
  strawberrySpeed = random([5, 6, 7, 8])
  watermelonSpeed = random([5, 6, 7, 8])
  blueberrySpeed = random([5, 6, 7, 8])
  bombSpeed = random([5, 6, 7, 8])
}

function draw() {
  //sound
  var vol = amp.getLevel();
  var diam = map(vol, 0, 0.3, 0, 255);

  //the code in the if statement below draws the intro screen
  if (screen == "intro"){
    background(189,183, 107);
  
    r = random(255); 
    g = random(255); 
    b = random(255); 
    a = random(255); 
    for(var i = 0; i <=300; i+=30){
      noStroke()
      fill(r, g, b, a);
      ellipse(x-450+i,  y-400, 40, 40);
    }
    
    //ninja picture
    image(ninja, 300, 350, 300, 300);
    textSize(65);
    textFont("Cooper");
    fill(0);
    text ("FRUIT NINJA", x/10, y/5);
    
    //theme
    textSize(30);
    text("String Methods", x/3.4, y/2.85)
    
    //authors names
    textSize(30);
    text("By:", x-560, y-150);
    
    text("Sakshi Goel", x-560, y-110);
    text("Marcus Zamparo", x-560, y-70);
    
    
    //how to play button
    fill (0);
    if ( mouseX>=100 && mouseX<=250 && mouseY>=300 && mouseY<=340 ) {
      fill(0, 0, 139); // click color
    }    
    rect(100, 300, 150, 40);  // the button    
    textSize(20);
    fill(255);
    text("How To Play", 110, 327);    
    
    //play button
    fill (0);//red
    //the code below creates a nice roll over effect
    if ( mouseX>=340 && mouseX<=490 && mouseY>=300 && mouseY<=340 ) { 
      fill(0, 128, 0); // click color
    }      
    score = 0;
    rect(340, 300, 150, 40);  //the button    
    fill(255);
    text("Play", 390, 325);     
  }
  
  //the code in the if statement below draws the "how to play" screen  
  if (screen == "howToPlay"){
    background(238,232,170);
    noStroke()
    textSize(50);
    text ("How To Play", x/4, y/6);
    
    //instructions
    textSize(20)
    text("1. Move your mouse around to slice fruits",x/10, y/3.3 );
    text("2. Avoid the bombs", x/10, y/2.7);
    text("3. Answer a question if you die", x/10, y/2.3);
    text("4. If you get it right your life is revived",x/10, y/2);
    text("5. Don't miss any fruits or you lose lives",x/10, y/1.75);
    text("6. Get to 20 points and you win!",x/10, y/1.55);
    
    //apple
    noStroke();
    fill(255, 0, 0);
    
    circle(200, 450, 60)
    fill(0,128,0)
  
    //stem
    stroke(165,42,42);
    strokeWeight(4)
    line(200, 430, 190,410)

    //leaf
    stroke(127,255,0)
    fill(127,255,0)
    triangle(198, 415, 200, 420, 210, 415)
  
    //green apple
    noStroke();
    fill(127,255,0)
    circle(480, 450, 60)
    fill(0,128,0)
  
    //stem
    stroke(165,42,42);
    strokeWeight(4)
    line(480, 430, 470,410)

    //leaf
    stroke(127,255,0)
    fill(127,255,0)
    
    //carrot
    stroke(255,140,0)
    fill(255,140,0)
    triangle(97, 425, 143, 425, 120, 465)
    //leafs
    stroke(50,205,50)
    fill(50,205,50)
    var cLeafX = 100
    var cLeafY = 420
  
    for(var k = 0; k <=4; k++){
      circle(cLeafX, cLeafY, 10 )
      cLeafX +=10
    }
    
    //watermelon
    fill(255, 71, 26)
    stroke(102, 204, 0)
    strokeWeight(4)
    arc(300,430, 70,70,0,PI);
    noStroke();
    fill(0)
    ellipse(320,440,2,8)
    ellipse(280,440,2,8)
    
    //blueberries
    fill(51, 0, 153)
    ellipse(400,440,60,55)
    fill(170, 128, 255)
    ellipse(400,420,25,10)  
    
    //Back button
    noStroke()
    fill(255);
    //the code below creates a nice roll over effect
    if ( mouseX>=x-110 && mouseX<=x+50 && mouseY>=y-50 && mouseY<=y+140 ) { 
      fill(169, 169, 169); // click color
    }     
    rect(x-110, y-50, 100, 40);  // the button 
    fill(0);
    textSize(20);
    text("Back", x-90, y-20);
  }
  
  //the code in the if statement below draws the game screen
  if (screen == "gameScreen"){
    timer++;
    if (score >= 20 && screen=="gameScreen"){
      screen ="gameOver";
    }    
    
    background(0); 
    //Back button
    fill(255);
    //the code below creates a nice roll over effect
    if ( mouseX>=480 && mouseX<=580 && mouseY>=10 && mouseY<=50 ) { 
      fill(mouseX, mouseY, 100); // click color
    }    
    fill(255)
    noStroke()
    rect(480, 10, 100, 40);  // the back button 
    fill(0);
    textSize(25);
    text("Back", 500, 40);  
    
    //score display
    fill(255)
    text("Score: "+score, 20, 40)
    text("Lives:  "+lives, 20, 70)
    
    //calls knife and fruit functions
    drawKnife();
    apple(appleX, appleY, appleSize)
    greenApple(greenAppleX, greenAppleY, greenAppleSize)
    carrot(carrotX, carrotY)
    strawberry(strawberryX, strawberryY, strawberrySize)
    watermelon(watermelonX, watermelonY)
    blueberry(blueberryX, blueberryY)
    bomb(bombX, bombY)
    bomb2(bomb2X, bomb2Y)
    collisionCheck()
    appleCollision()
    greenAppleCollision()
    carrotCollision()
    strawberryCollision()
    watermelonCollision()
    blueberryCollision()
    bombCollision()
    bomb2Collision()
    noLives()

  }
  
   //the code in the if statement below draws the gameOver screen
  if(screen == "gameOver"){
    background(0,250,154);
    image(ninja, 300, 350, 300, 300)
    textSize(60)
    fill(0)
    text("You WON!", 170, 100);
    textSize(30)
    text("Press Play Again to Restart", 130, 180)
    fill (0);
    if ( mouseX>=80 && mouseX<=230 && mouseY>=300 && mouseY<=340 ) {    
      fill(235, 0, 0); // click color
    }    
    rect(80, 300, 150, 40);  // the button    
    textSize(20);
    fill(255);
    text("Play Again", 100, 327);
  
    r = random(255); 
    g = random(255); 
    b = random(255); 
    a = random(255); 
    for(var j = 0; j <=380; j+=61){
      noStroke()
      fill(r, g, b, a);
      rect(x-500+j,  y-460, 60, 60)
    }
  
  }
  if(screen == "quiz"){
    if(dist(mouseX, mouseY-35, bombX, bombY) < bombSize){
      bombX= (-1)*random(50, 800);
      bombY= random(50, 500);  
    } 
    drawBoard()
  }
  if(screen == "answer"){
    drawAnswer();
  }
}
  
function mouseClicked(){
  if (mouseX>=100 && mouseX<=250 && mouseY>=300 && mouseY<=340 && screen == "intro") { 
    screen="howToPlay"
  }
  else if (mouseX>=x-110 && mouseX<=x+50 && mouseY>=y-50 && mouseY<=y+140   && screen == "howToPlay") { 
    screen="intro";
  }
  else if (mouseX>=340 && mouseX<=490 && mouseY>=300 && mouseY<=340  && screen == "intro") { 
    screen="gameScreen";    
  }
  else if (mouseX>=480 && mouseX<=580 && mouseY>=10 && mouseY<=50 && screen == "gameScreen") { 
    screen="intro";
    appleX= (-1)*random(50, 550);
    appleY= random(50, 500);  
    greenAppleX= random(550, 1000);
    greenAppleY= random(50, 500);  
    carrotX= (-1)*random(50, 550);
    carrotY= random(50, 550);  
    watermelonX= random(650, 1000);
    watermelonY= random(50, 550); 
    blueberryX = random(650, 1000);
    blueberryY = random(650, 1000);
    bombX = random(650, 1000);
    bombY = random(50, 550);
    bomb2X = (-1)*random(50, 550)
    bomb2Y = random(50, 550)
  }
  
  //quiz
  //a
  if(screen == "quiz" && mouseX >=130 && mouseX <= 530 && mouseY >=190 && mouseY <= 290){
    print("button A pressed")
    userAnswerA = "A"
  }
  //b
  if(screen == "quiz" && mouseX >=130 && mouseX <= 530 && mouseY >=310 && mouseY <= 400){
    print("button B pressed")
    userAnswerB = "B"
  }
  //c
  if(screen == "quiz" && mouseX >=130 && mouseX <= 530 && mouseY >=350 && mouseY <= 450){
    print("button C pressed")
    userAnswerC = "C"
  }  
  //d
  if(screen == "quiz" && mouseX >=130 && mouseX <= 530 && mouseY >=450 && mouseY <= 550){
    print("button D pressed")
    userAnswerD = "D"
  }  
  //shows answers when arrow is clicked
  if(screen == "quiz" && mouseX >= 480 && mouseX <= 560 && mouseY >= 70 && mouseY <= 150 && userAnswerA || screen == "quiz" && mouseX >= 480 && mouseX <= 560 && mouseY >= 70 && mouseY <= 150 && userAnswerB || screen == "quiz" && mouseX >= 480 && mouseX <= 560 && mouseY >= 70 && mouseY <= 150 && userAnswerC || screen == "quiz" && mouseX >= 480 && mouseX <= 560 && mouseY >= 70 && mouseY <= 150 && userAnswerD){
    screen = "answer"
  }

  if(screen == "answer" && mouseX >= 480 && mouseX <= 560 && mouseY >= 70 && mouseY <= 150){
    screen = "gameScreen"
    appleX= (-1)*random(50, 550);
    appleY= random(50, 500);  
  
    greenAppleX= random(550, 1000);
    greenAppleY= random(50, 500);  
  
    carrotX= (-1)*random(50, 550);
    carrotY= random(50, 550);  

    watermelonX= random(650, 1000);
    watermelonY= random(50, 550); 
  
    blueberryX = random(650, 1000);
    blueberryY = random(650, 1000);
    
    bombX = random(650, 1000);
    bombY = random(50, 550);
  
    bomb2X = (-1)*random(50, 550)
    bomb2Y = random(50, 550)
    randomQuestion = random([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    userAnswerA = ""
    userAnswerB = ""
    userAnswerC = ""
    userAnswerD = ""

  }
  if(mouseX>=80 && mouseX<=230 && mouseY>=300 && mouseY<=340 && screen == "gameOver"){
    screen = "intro";
    score = 0;
    lives = 10;
    appleX= (-1)*random(50, 550);
    appleY= random(50, 500);  
  
    greenAppleX= random(550, 1000);
    greenAppleY= random(50, 500);  
  
    carrotX= (-1)*random(50, 550);
    carrotY= random(50, 550);
  
    strawberryX= (-1)*random(50, 550);
    strawberryY= random(50, 550);

    watermelonX= random(650, 1000);
    watermelonY= random(50, 550); 
  
    blueberryX = random(650, 1000);
    blueberryY = random(650, 1000);
  
    bombX = random(650, 1000);
    bombY = random(50, 550);
  
    bomb2X = (-1)*random(50, 550)
    bomb2Y = random(50, 550)
  
    randomQuestion = random([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    
  }
  
  print("screen "+ screen);
}  

function drawKnife(){
  if(mouseX>300 && mouseX<570){
    // RIGHT Knife Handle
    fill(80);
    rect(mouseX, mouseY-5, 15, 40);
    // RIGHT Knife Blade
    fill(160);
    rect(mouseX, mouseY-60, 30, 60, 5);
    // RIGHT Knife Sharp
    fill(200);
    rect(mouseX+20, mouseY-60, 10, 60);
    // RIGHT Handle Holes
    for(let i=mouseY+10; i<mouseY+30; i=i+15){
      circle(mouseX+7.5, i, 8);
    }  
  }
  
  else if(mouseX<300){
    // LEFT Knife Handle
    fill(80);
    rect(mouseX+15, mouseY-5, 15, 40);
    // LEFT Knife Blade
    fill(160);
    rect(mouseX, mouseY-60, 30, 60, 5);
    // LEFT Knife Sharp
    fill(200);
    rect(mouseX, mouseY-60, 10, 60);
    // LEFT Handle Holes
    for(let i=mouseY+10; i<mouseY+30; i=i+15){
      circle(mouseX+22.5, i, 8);
    }
  }
  
  if(mouseX>570){
    // RIGHT Knife Handle
    fill(80);
    rect(570, mouseY-5, 15, 40);
    // RIGHT Knife Blade
    fill(160);
    rect(570, mouseY-60, 30, 60, 5);
    // RIGHT Knife Sharp
    fill(200);
    rect(570+20, mouseY-60, 10, 60);
    // RIGHT Handle Holes
    for(let i=mouseY+10; i<mouseY+30; i=i+15){
      circle(577.5, i, 8);
    }
  }
}

function apple(){
  noStroke();
  fill(255, 0, 0)
  circle(appleX, appleY, appleSize)
  fill(0,128,0)
  
  //stem
  stroke(165,42,42);
  strokeWeight(4)
  line(appleX, appleY-20, appleX - 10, appleY - 40)

  //leaf
  stroke(127,255,0)
  fill(127,255,0)
  triangle(appleX-2, appleY -35,appleX, appleY -30, appleX +10, appleY - 35)
  
  appleX +=appleSpeed;

  if(appleX >=700){
    appleX= (-1)*random(50, 800);
    lives --;
  }
  
}

function greenApple(){
  noStroke();
  fill(127,255,0)
  circle(greenAppleX, greenAppleY, greenAppleSize)
  fill(0,128,0)
  
  //stem
  stroke(165,42,42);
  strokeWeight(4)
  line(greenAppleX, greenAppleY-20, greenAppleX - 10, greenAppleY - 40)

  //leaf
  stroke(127,255,0)
  fill(127,255,0)
  triangle(greenAppleX-2, greenAppleY -35, greenAppleX, greenAppleY -30, greenAppleX +10, greenAppleY - 35)
  
  greenAppleX -= greenAppleSpeed;
  
   
if(greenAppleX <=-50){
    greenAppleX = random(650, 1000)
    lives --;
  }
  
}

function carrot(){  
  //carrot
  stroke(255,140,0)
  fill(255,140,0)
  triangle(carrotX-3, carrotY, carrotX + 43, carrotY, carrotX + 20, carrotY + 40)
  //leafs
  stroke(50,205,50)
  fill(50,205,50)
  var cLeafX = carrotX
  var cLeafY = carrotY-2
  
  for(var k = 0; k <=4; k++){
    circle(cLeafX, cLeafY, 10 )
    cLeafX +=10
  }
  
    carrotX +=carrotSpeed;
  
  if(carrotX >=700){
    carrotX= (-1)*random(50, 550);
    lives --;
  }
}

function strawberry(){
  //carrot
  stroke(240,128,128)
  fill(240,128,128)
  triangle(strawberryX-3, strawberryY, strawberryX + 43, strawberryY, strawberryX + 20, strawberryY + 40)
  //leafs
  stroke(50,205,50)
  fill(50,205,50)
  var cLeafX = strawberryX
  var cLeafY = strawberryY-2
  
  for(var k = 0; k <=4; k++){
    circle(cLeafX, cLeafY, 10 )
    cLeafX +=10
  }
  
    strawberryX +=strawberrySpeed;
  
  if(strawberryX >=700){
    strawberryX= (-1)*random(50, 550);
    lives --;
  }
}

function watermelon(){
  fill(255, 71, 26)
  stroke(102, 204, 0)
  strokeWeight(4)
  arc(watermelonX,watermelonY, 70,70,0,PI);
  noStroke();
  fill(0)
  ellipse(watermelonX + 20, watermelonY + 10,2,8)
  ellipse(watermelonX - 20, watermelonY + 10,2,8)
  
  watermelonX -=watermelonSpeed;
  if(watermelonX <=-50){
    watermelonX = random(650, 1000)
    lives --;
  }
}

function blueberry(){
  //blueberries
  fill(51, 0, 153)
  ellipse(blueberryX,blueberryY-106,60,55)
  fill(170, 128, 255)
  ellipse(blueberryX,blueberryY - 125 ,25,10)
  
  blueberryX -= blueberrySpeed;
  
   if(blueberryX <=-50){
   blueberryX = random(650, 1000)
   blueberryY = random(100, 500)
   lives --;
  }
  
}

function bomb(){
  if(timer >=5){
  //bomb
  fill(0)
  strokeWeight(5)
  stroke(255, 0, 0)
  ellipse(bombX - 150,bombY,60,60)
  noStroke()
  fill(255, 0, 0)
  textFont('Arial')
  textSize(40)
  text("x", bombX - 160, bombY +10)
  
  bombX -= bombSpeed;
  
   if(bombX <=-50){
   bombX = random(650, 1000)
   bombY = random(50, 550)
   }
  }
}

function bomb2(){
  if(timer >=5){
  //bomb
  fill(0)
  strokeWeight(5)
  stroke(255, 0, 0)
  ellipse(bomb2X - 150,bomb2Y,60,60)
  noStroke()
  fill(255, 0, 0)
  textFont('Arial')
  textSize(40)
  text("x", bomb2X - 160, bomb2Y +10)
  
  bomb2X += bombSpeed;
  
   if(bomb2X >=700){
     bomb2X = (-1)*random(650, 1000)
     bomb2Y = random(50, 550)
   }
  }
}
function collisionCheck (other_x, other_y, other_width, other_height){
  return (mouseX < other_x + other_width) && (mouseX + (mouseX+50) > other_x)  && (mouseY-40 < other_y + other_height) && (mouseY-40 + (mouseY+30) > other_y);
}

function bombCollision(){
  //collision check
  if(dist(mouseX, mouseY-35, bombX, bombY) < bombSize+50){
    bombX= (-1)*random(50, 800);
    bombY= random(50, 500);  
    screen = "quiz";
  
  } 
}

function noLives(){
  if(lives <=0){
    screen = "quiz";
  }
}

function bomb2Collision(){
   //collision check
  if(dist(mouseX, mouseY-35, bombX, bombY) < bombSize){
    bombX= (-1)*random(50, 800);
    bombY= random(50, 500);  
    screen = "quiz"
  
 } 
}

function appleCollision(){
      //collision check
    if(dist(mouseX, mouseY-35, appleX, appleY) < appleSize){
    appleX= (-1)*random(50, 800);
    appleY= random(50, 500);  
    score ++
  
 } 
}

function greenAppleCollision(){
      //collision check
    if(dist(mouseX, mouseY-35, greenAppleX, greenAppleY) < greenAppleSize){
    greenAppleX= (-1)*random(50, 800);
    greenAppleY= random(50, 500);  
    score ++
  
 } 
}
function carrotCollision(){
      //collision check
    if(dist(mouseX, mouseY-35, carrotX, carrotY) < carrotSize){
    carrotX= (-1)*random(50, 800);
    carrotY= random(50, 500);  
    score ++
  
 } 
}

function strawberryCollision(){
      //collision check
    if(dist(mouseX, mouseY-35, strawberryX, strawberryY) < strawberrySize){
    strawberryX= (-1)*random(50, 800);
    strawberryY= random(50, 500);  
    score ++
  
 } 
}

function watermelonCollision(){
      //collision check
    if(dist(mouseX, mouseY-35, watermelonX, watermelonY) < watermelonSize){
    watermelonX= (-1)*random(50, 800);
    watermelonY= random(50, 500);  
    score ++
  
 } 
}

function blueberryCollision(){
      //collision check
 if(dist(mouseX, mouseY-35, blueberryX, blueberryY) < blueberrySize +50){
    blueberryX= (-1)*random(50, 800);
    blueberryY= random(50, 500);  
   score ++
  
 } 
}

function drawBoard(){
   background(mouseX, mouseY, 200);

   stroke(0);
   textAlign(LEFT);
   // the board
   fill(30, 144, 255, 100);
   rect(40, 160, 520, 420, 20);
  
 // Question Boxes
   for(boxY = 190; boxY < 550; boxY +=100) {
     fill(30, 144, 255);
     rect(130, boxY, 400, 60);
   } 
  
  //checking answer for box a
  if(userAnswerA == answer[randomQuestion]){
    fill(124,252,0);
    rect(130, 190, 400, 60);
    timer2 ++
  }
  if(answer[randomQuestion] == "B" && userAnswerA){
    fill(255,0,0)
    rect(130, 190, 400, 60);
    score = 0;
    lives = 0;
    timer2 ++
  }
  if(answer[randomQuestion] == "C" && userAnswerA){
    fill(255,0,0)
    rect(130, 190, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  if(answer[randomQuestion] == "D" && userAnswerA){
    fill(255,0,0)
    rect(130, 190, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  
  //checking answer for box b
  if(userAnswerB == answer[randomQuestion]){
    fill(124,252,0);
    rect(130, 290, 400, 60);
    timer2++
  }
  if(answer[randomQuestion] == "A" && userAnswerB){
    fill(255,0,0)
    rect(130, 290, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  if(answer[randomQuestion] == "C" && userAnswerB){
    fill(255,0,0)
    rect(130, 290, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  if(answer[randomQuestion] == "D" && userAnswerB){
    fill(255,0,0)
    rect(130, 290, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }  
  
  //checking answer for box c
  if(userAnswerC == answer[randomQuestion]){
    fill(124,252,0);
    rect(130, 390, 400, 60);
    timer2++
  }
  if(answer[randomQuestion] == "A" && userAnswerC){
    fill(255,0,0)
    rect(130, 390, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  if(answer[randomQuestion] == "B" && userAnswerC){
    fill(255,0,0)
    rect(130, 390, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  if(answer[randomQuestion] == "D" && userAnswerC){
    fill(255,0,0)
    rect(130, 390, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  
  //checking answer for box d
  if(userAnswerD == answer[randomQuestion]){
    fill(124,252,0);
    rect(130, 490, 400, 60);
    timer2++
  }
  if(answer[randomQuestion] == "A" && userAnswerD){
    fill(255,0,0)
    rect(130, 490, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  if(answer[randomQuestion] == "B" && userAnswerD){
    fill(255,0,0)
    rect(130, 490, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }
  if(answer[randomQuestion] == "C" && userAnswerD){
    fill(255,0,0)
    rect(130, 490, 400, 60);
    score = 0;
    lives = 0;
    timer2++
  }

   stroke(0)
  // Number Circle
  for(var circleY = 220; circleY < 550; circleY +=100) {
     fill(30, 144, 255);
     circle(82, circleY, 60);
   } 
  fill(0)
  noStroke()
  textFont("Cooper")
  
  //prints a b c d options
  text(optionA[randomQuestion], textX, textY)
  text(optionB[randomQuestion], textX, textY+100)
  text(optionC[randomQuestion], textX, textY+200)
  text(optionD[randomQuestion], textX, textY+300)
  
   // Question Spot
   //rect(0, 0, 600, 130);
   
   if(randomQuestion == 0){
      textSize(30)
      text(question[randomQuestion], 60, 40)
     fill(32,178,170)
       textSize(17)
   text(code[randomQuestion], 200, 65)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
   }
  if(randomQuestion == 1){
       textSize(30)
      text(question[randomQuestion], 60, 40)
    fill(32,178,170)
  textSize(17)
   text(code[randomQuestion], 200, 65)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
  }   
  if(randomQuestion == 2){
    textSize(27)
    text(question[randomQuestion], 40, 50)
    textSize(30)
    image(arrow, 490, 70, 80, 80)
    lives = 10;
  }
  if(randomQuestion == 3){
   textSize(30)
   text(question[randomQuestion], 60, 40)
   fill(32,178,170)
   textSize(17)
   text(code[randomQuestion], 60, 100)
   textSize(30)
  image(arrow, 480, 70, 60, 60)
  lives = 10;
  }
  if(randomQuestion == 4){
   textSize(30)
   text(question[randomQuestion], 60, 40)
   fill(32,178,170)
   textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
  }
  if(randomQuestion == 5){
         textSize(30)
   text(question[randomQuestion], 60, 40)
   fill(32,178,170)
   textSize(17)
   text(code[randomQuestion], 100, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
  }
  if(randomQuestion == 6){
         textSize(30)
      text(question[randomQuestion], 60, 40)
   fill(32,178,170)
   textSize(17)
   text(code[randomQuestion], 100, 90)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
  }
  if(randomQuestion == 7){
         textSize(30)
      text(question[randomQuestion], 60, 40)
  fill(32,178,170)
  textSize(17)
  text(code[randomQuestion], 90, 100)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
  }
  if(randomQuestion == 8){
    textSize(30)
    text(question[randomQuestion], 37, 50)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
  }
   if(randomQuestion == 9){
    textSize(30)
   text(question[randomQuestion], 60, 40)
   fill(32,178,170)
   textSize(16)
   text(code[randomQuestion], 20, 105)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  lives = 10;
  }
  

}

function drawAnswer(){
  background(mouseX, mouseY, 200);

   stroke(0);
   textAlign(LEFT);
   // the board
   fill(30, 144, 255, 100);
   rect(40, 160, 520, 420, 20);
  
 // Question Boxes
   for(boxY = 190; boxY < 550; boxY +=100) {
     fill(30, 144, 255);
     rect(130, boxY, 400, 60);
   } 
    stroke(0)
  
  //colours correct and incorrect answers
  if(answer[randomQuestion] == "A"){
    fill(124,252,0);
    rect(130, 190, 400, 60);
    fill(255, 0, 0)
    rect(130, 290, 400, 60)
    rect(130, 390, 400, 60)
    rect(130, 490, 400, 60)
  }
  if(answer[randomQuestion] == "B"){
    fill(255, 0, 0)
    rect(130, 190, 400, 60);
    fill(124,252,0);
    rect(130, 290, 400, 60);
    fill(255, 0, 0)
    rect(130, 390, 400, 60)
    rect(130, 490, 400, 60)
  }
  if(answer[randomQuestion] == "C"){
    fill(255, 0, 0)
    rect(130, 190, 400, 60);
    rect(130, 290, 400, 60);
    fill(124,252,0);
    rect(130, 390, 400, 60)
    fill(255, 0, 0)
    rect(130, 490, 400, 60)
  }  
  if(answer[randomQuestion] == "D"){
    fill(255, 0, 0)
    rect(130, 190, 400, 60);
    rect(130, 290, 400, 60);
    rect(130, 390, 400, 60)
    fill(124,252,0);
    rect(130, 490, 400, 60)
  }  
  
  // Number Circle
  for(var circleY = 220; circleY < 550; circleY +=100) {
     fill(30, 144, 255);
     circle(82, circleY, 60);
   } 
  fill(0)
  noStroke()
  textFont("Cooper")
  
  //prints a b c d options
  text(optionA[randomQuestion], textX, textY)
  text(optionB[randomQuestion], textX, textY+100)
  text(optionC[randomQuestion], textX, textY+200)
  text(optionD[randomQuestion], textX, textY+300)
  
   // Question Spot
   //rect(0, 0, 600, 130);
   if(randomQuestion == 0){
      textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
   }
  if(randomQuestion == 1){
       textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }   
  if(randomQuestion == 2){
    textSize(27)
    text(question[randomQuestion], 40, 50)
         textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
    image(arrow, 490, 70, 80, 80)
     //lives = 10;
  }
  if(randomQuestion == 3){
         textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }
  if(randomQuestion == 4){
         textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }
  if(randomQuestion == 5){
         textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(19)
   text(code[randomQuestion], 60, 90)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }
  if(randomQuestion == 6){
         textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }
  if(randomQuestion == 7){
         textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }
  if(randomQuestion == 8){
    textSize(30)
    text(question[randomQuestion], 37, 50)
         textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }
   if(randomQuestion == 9){
         textSize(30)
      text(question[randomQuestion], 60, 40)
       textSize(15)
   text(code[randomQuestion], 60, 70)
   textSize(30)
     image(arrow, 480, 70, 60, 60)
  //lives = 10;
  }
}
function play() {
  if (!song.isPlaying()) {
    song.play();

  } else {
    song.pause();

  }
}